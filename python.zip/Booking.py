class Booking:
    def __init__(self,guestName,roomNum,guestId,guestNum,checkinDay,checkoutDay):
        self.guestName = guestName
        self.roomNum = roomNum
        self.guestId = guestId 
        self.guestNum = guestNum
        self.checkinDay = checkinDay
        self.checkoutDay = checkoutDay
