class Guest:
    def __init__(self,name,guestId):
        self.name = name
        self.guestId = guestId
