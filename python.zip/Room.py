class Room:
    def __init__(self,roomNum,roomCapacity):
        self.roomNum = roomNum
        self.roomCapacity = roomCapacity